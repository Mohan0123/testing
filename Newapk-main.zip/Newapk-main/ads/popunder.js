/* ===============================
   POPUNDER SCRIPT
================================ */
(function () {
  // Unique key per page
  const pageKey = "ranginx_pop_" + location.pathname;

  // Agar is page par pop already hua hai → exit
  if (sessionStorage.getItem(pageKey)) return;

  function triggerPop() {
    // Mark this page as popped
    sessionStorage.setItem(pageKey, "1");

    // Load popunder script
    const pop = document.createElement("script");
    pop.src = "https://joyfullybarn.com/42/76/48/427648720fc5f808a6c9fd6d7d4af36d.js";
    pop.async = true;
    document.body.appendChild(pop);

    // Remove click listener (1 time only)
    document.removeEventListener("click", triggerPop);
  }

  // Trigger only on real user click
  document.addEventListener("click", triggerPop);
})();



/* ===============================
   SOCIAL BAR SCRIPT
================================ */
(function () {
  const social = document.createElement("script");
  social.src = "https://joyfullybarn.com/f5/76/ea/f576ea86d7e7c1a91485425829516236.js";
  social.async = true;
  document.body.appendChild(social);
})();
